/*
First, create a function called getAverage(nums) which takes a single array of
numbers and returns the average.

Then, write a function highestAverage(numsList) that takes in a
2-dimensional array of numbers and returns THE INDEX of the sub-array with the
highest average value.

Constraint: Use the getAverage function as a helper function in the
highestAverage function to solve the problem.
*/

function getAverage(nums) {
  let total = 0;
  for (let i = 0; i < nums.length; i++) {
    total += nums[i];
  }
  return total / nums.length;
}

function highestAverage(numsList) {
  // for (let j = 0; j < numsList; j++) {
  //   if (getAverage(numsList[j]) > getAverage(numsList[j - 1])) {
  //   }
  //   return getAverage(numsList[j]);
  // }
}

// const arrayA = [1, 2, 3, 4, 5];
// const arrayB = [10000, -9998];
// const arrayC = [2, 100, 55, 19];
// const arrayD = [4, 8, 12];

// console.log(getAverage(arrayA)); // 3
// console.log(getAverage(arrayB)); // 1
// console.log(getAverage(arrayC)); // 44
// console.log(getAverage(arrayD)); // 8

// console.log(highestAverage([arrayA, arrayB, arrayC, arrayD])); // 2
// console.log(highestAverage([arrayA, arrayB])); // 0
// console.log(highestAverage([arrayA, arrayD])); // 1

/******************** DO NOT MODIFY ANY CODE BELOW THIS LINE *****************/
module.exports = {
  getAverage,
  highestAverage,
};
